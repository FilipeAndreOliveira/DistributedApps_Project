from flask import Flask, render_template, request, send_from_directory, redirect, jsonify
import os
import qrcode 
from flask_cors import CORS
import base64

app = Flask(__name__)
CORS(app)
     
@app.route("/")
def index():
    return render_template("index.html", message="Dynamic content!")   

@app.route("/newQR", methods=['GET','POST'])
def QRCode():
    if request.method == 'GET':
        return render_template("newQR.html")
    elif request.method == 'POST':
        QRtext = request.form["QRName"] 
        QRname = QRtext + ".jpeg"
        QRimg = qrcode.make(QRtext)
        directory = "/home/mint//Desktop/ADINT/Week 6 - Class 11/files/"
        QRpath = directory + QRname
        QRimg.save(os.path.join(directory, QRname), "JPEG", quality=95)
        
        # file verification
        if not os.path.exists(QRpath):
            return redirect('/failure'), QRname
    
        # send file
        return send_from_directory(directory, QRname, as_attachment=True)


@app.route("/newQR2", methods=['GET'])
def generateQRCode():
    #QRtext = request.form["QRName"]
    QRtext = request.args.get("QRName")
    QRname = QRtext + ".jpeg"
    QRimg = qrcode.make(QRtext)
    directory = "/home/mint//Desktop/ADINT/Week 6 - Class 11/files/"
    QRpath = os.path.join(directory, QRname)
    QRimg.save(QRpath, "JPEG", quality=95)

    #generatedPath = 'http://127.0.0.1:8000' + directory + QRname

    # Check if the file was successfully saved
    if os.path.exists(QRpath):
        return send_from_directory(directory, QRname, as_attachment=False) #base64.b64encode()
    else:
        return jsonify({'success': False, 'message': 'Failed to generate QR code'})

# Serve the generated QR code image
#@app.route('/downloadQR/<qr_name>')
#def downloadQR(qr_name):
#    return send_from_directory(directory, qr_name, as_attachment=True)



if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8009, debug=True)



