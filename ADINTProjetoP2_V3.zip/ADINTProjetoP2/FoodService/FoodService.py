from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, ForeignKey

from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.exc import NoResultFound

from os import path

from flask import Flask, render_template, request
from flask_xmlrpcre.xmlrpcre import *

app = Flask(__name__)

handler = XMLRPCHandler('api')
handler.connect(app, '/api')


#SLQ access layer initialization
DATABASE_FILE = "database.sqlite"
db_exists = False
if path.exists(DATABASE_FILE):
    db_exists = True
    print("\t database already exists")

engine = create_engine('sqlite:///%s'%(DATABASE_FILE), echo=False) #echo = True shows all SQL calls

Base = declarative_base()
#Base.metadata.create_all(engine)

# Data structures:
class Restaurants(Base):
    __tablename__ = 'restaurants'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    def __repr__(self):
        return "<Restaurant(id=%d, name='%s')>" % (self.id, self.name)
    
class Meal(Base):
    __tablename__ = 'meal'
    id = Column(Integer, primary_key=True)
    fkRestaurant = Column(Integer, ForeignKey('restaurants.id'))
    price = Column(Float)
    name = Column(String)
    restaurants = relationship("Restaurants", back_populates="meal")

    def __repr__(self):
        return "<Meal(id=%d, fk =%d, price=%f, name='%s')>" % (self.id, self.fkRestaurant, self.name, self.price)
    
class Evaluation(Base):
    __tablename__ = 'evaluation'
    id = Column(Integer, primary_key=True)
    fkRestaurant = Column(Integer, ForeignKey('restaurants.id'))
    eval = Column(Integer)
    restaurants = relationship("Restaurants", back_populates="evaluation")

    def __repr__(self):
        return "<Evaluation(id=%d, eval='%s')>" % (self.id, self.fkRestaurant, self.eval)

Restaurants.meal = relationship(
    "Meal", order_by=Meal.id, back_populates="restaurants")

Restaurants.evaluation = relationship(
    "Evaluation", order_by=Evaluation.id, back_populates="restaurants")

Base.metadata.create_all(engine) 

Session = sessionmaker(bind=engine)
session = Session()  

###

@handler.register
def newRestaurant(name):
    restaurant = Restaurants(name=name)
    session.add(restaurant)
    session.commit()

@handler.register
def newMenu(name, fkRestaurant, price):
    meal = Meal(name = name, fkRestaurant=fkRestaurant, price=price)
    session.add(meal)
    session.commit()

@handler.register
def updateMeal(menuID, menuName,restaurantID, menuPrice):
    try:
        # Query the meal by ID to verify its existence
        meal = session.query(Meal).filter_by(id=menuID).one()

        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        # Update the meal's name and price
        meal.name = menuName
        meal.price = menuPrice
        meal.fkRestaurant = restaurant.id

        session.commit()

        print(f"Menu item updated:")
        print(f"Meal ID: {meal.id}, New Name: {meal.name}, New Price: {meal.price}")

        return True  # Return True to indicate a successful update
    except NoResultFound:
        print(f"Meal '{menuID}' not found.")
        return False  # Return False to indicate an error         
    
@handler.register
def listRestaurants():
    rest = session.query(Restaurants).all()
    restaurant_list = []

    for restaurant in rest:
        restaurant_data = {
            "id": restaurant.id,
            "name": restaurant.name,
        }
        restaurant_list.append(restaurant_data)

    return restaurant_list       

@handler.register
def nameRestaurants_fromID(restaurantID):
    restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()
    restaurantName = restaurant.name
    return restaurantName

### even more usefull functions:

@handler.register
def list_meals_by_restaurant(restaurantID):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        # Query the meals associated with the restaurant
        meals = session.query(Meal).filter_by(fkRestaurant=restaurant.id).all()

        # Create a list to store meal data as dictionaries
        meal_list = []

        # Prepare the meal data and append to the list
        for meal in meals:
            meal_data = {
                "id": meal.id,
                "name": meal.name,
                "price": meal.price
            }
            meal_list.append(meal_data)

        if meal_list:
            print(f"Meals at {restaurant.name}:")
            for meal_data in meal_list:
                print(f"- {meal_data['name']}, Price: {meal_data['price']}")

        else:
            print(f"No meals found for {restaurant.name}.")

        return meal_list
    except NoResultFound:
        print(f"Restaurant '{restaurantID}' not found.")

@handler.register
def create_evaluation(restaurantID, eval_value):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        # Create a new evaluation
        evaluation = Evaluation(fkRestaurant=restaurant.id, eval=eval_value)

        # Add the evaluation to the database
        session.add(evaluation)
        session.commit()

        print(f"New evaluation created for {restaurant.name}:")
        print(f"Evaluation ID: {evaluation.id}, Value: {evaluation.eval}")

        return True  # Return True to indicate a successful creation
    except NoResultFound:
        print(f"Restaurant '{restaurantID}' not found.")
        return False  # Return False to indicate an error

## PARTE 2 ADAPTACAO DISTO:

@handler.register
def create_evaluation_byName(restaurantName,eval_value):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(name=restaurantName).one()

        # Create a new evaluation
        evaluation = Evaluation(fkRestaurant=restaurant.id, eval=eval_value)

        # Add the evaluation to the database
        session.add(evaluation)
        session.commit()

        print(f"New evaluation created for {restaurant.name}:")
        print(f"Evaluation ID: {evaluation.id}, Value: {evaluation.eval}")

        return True  # Return True to indicate a successful creation
    except NoResultFound:
        print(f"Restaurant '{restaurantName}' not found.")
        return False  # Return False to indicate an error


@handler.register
def list_evaluations_by_restaurant(restaurantID):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        # Query the evaluations associated with the restaurant
        evaluations = session.query(Evaluation).filter_by(fkRestaurant=restaurant.id).all()

        # Create a list to store evaluation data as dictionaries
        evaluation_list = []

        # Prepare the evaluation data and append to the list
        for evaluation in evaluations:
            evaluation_data = {
                "id": evaluation.id,
                "eval": evaluation.eval
            }
            evaluation_list.append(evaluation_data)

        if evaluation_list:
            print(f"Evaluations for {restaurant.name}:")
            for evaluation_data in evaluation_list:
                print(f"- Evaluation ID: {evaluation_data['id']}, Value: {evaluation_data['eval']}")

        else:
            print(f"No evaluations found for {restaurant.name}.")

        return evaluation_list
    except NoResultFound:
        print(f"Restaurant '{restaurantID}' not found.")
        
@handler.register
def update_menu(restaurantID, mealID, new_name, new_price):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        try:
            # Query the meal by ID to verify its existence
            meal = session.query(Meal).filter_by(id=mealID).one()

            # Update the meal's name and price
            meal.name = new_name
            meal.price = new_price

            session.commit()

            print(f"Menu item updated for {restaurant.name}:")
            print(f"Updated Meal: {meal.name}, New Price: {meal.price}")

            return True  # Return True to indicate a successful update
        except NoResultFound:
            newMenu(new_name, restaurantID, new_price)
            print(f"New Menu created for {restaurant.name}:")
            return True # New menu successfully created

    except NoResultFound:
        print(f"Restaurant '{restaurantID}' or Meal '{mealID}' not found.")
        return False  # Return False to indicate an error
    
@handler.register
def create_evaluation(restaurantID, eval_value):
    try:
        # Query the restaurant by ID to verify its existence
        restaurant = session.query(Restaurants).filter_by(id=restaurantID).one()

        # Create a new evaluation
        evaluation = Evaluation(fkRestaurant=restaurant.id, eval=eval_value)

        # Add the evaluation to the database
        session.add(evaluation)
        session.commit()

        print(f"New evaluation created for {restaurant.name}:")
        print(f"Evaluation ID: {evaluation.id}, Value: {evaluation.eval}")

        return True  # Return True to indicate a successful creation
    except NoResultFound:
        print(f"Restaurant '{restaurantID}' not found.")
        return False  # Return False to indicate an error

# Cenas da web App

@app.route("/")
def index():
    try:
        # Query the list of restaurants
        restaurant_list = listRestaurants() 

        return render_template("index.html", message="Click a Restaurants Check the Menu!", restaurants=restaurant_list)
    except Exception as e:
        return str(e)
    
@app.route('/detailRestaurants/<int:restaurant_id>', methods=['GET','POST'])
def showDetails(restaurant_id):
        menu = list_meals_by_restaurant(restaurant_id)
        eval = list_evaluations_by_restaurant(restaurant_id)
        restaurantName = nameRestaurants_fromID(restaurant_id)
        return render_template("detailRestaurant.html",restaurantName=restaurantName, restaurantID=restaurant_id, menu=menu, eval=eval)
        

@app.route('/submitEvaluation/<int:restaurant_id>', methods=['GET', 'POST'])
def gratitudeRestaurant(restaurant_id):
    restaurant = session.query(Restaurants).filter_by(id=restaurant_id).one()
    evaluation = request.form["rating"]
    create_evaluation(restaurant_id, evaluation)
    #evaluationList = list_evaluations_by_restaurant(restaurant_id)        
    #print('Criada nova avaliação!')
    return render_template("gratitudeRestaurant.html", message="agradece a sua avaliação!", restaurantName=restaurant.name )

app.run(host='0.0.0.0', port=8008, debug=True) #Debug=True



