from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, Boolean


import datetime
from sqlalchemy.orm import sessionmaker
from os import path

from flask import Flask, render_template, request
from flask_xmlrpcre.xmlrpcre import *
from datetime import datetime

app = Flask(__name__)

handler = XMLRPCHandler('api')
handler.connect(app, '/api')


#SLQ access layer initialization
DATABASE_FILE = "database.sqlite"
db_exists = False
if path.exists(DATABASE_FILE):
    db_exists = True
    print("\t database already exists")

engine = create_engine('sqlite:///%s'%(DATABASE_FILE), echo=False) #echo = True shows all SQL calls

Base = declarative_base()
#Base.metadata.create_all(engine)

# Create a Checkin model
class Checkin(Base):
    __tablename__ = 'checkin'
    id = Column(Integer, primary_key=True)
    user_name = Column(String(10), nullable=False) # Provavelmente será um ID
    location = Column(String(200), nullable=False)
    checkin_time = Column(DateTime, nullable=False)
    checkout_time = Column(DateTime, nullable=False)
    checked_out = Column(Boolean)

"""class Checkout(Base):
    __tablename__ = 'checkout'
    id = Column(Integer, primary_key=True)
    checkout_time = Column(DateTime, nullable=False)
    fkCheckin = Column(Integer, ForeignKey('checkin.id'))
    checkin = relationship("Checkin", back_populates="checkout")

Checkin.checkout = relationship(
    "Checkout", order_by=Checkout.id, back_populates="checkin")    """


Base.metadata.create_all(engine) #Create tables for the data models

Session = sessionmaker(bind=engine)
session = Session()


def getFalseChecked(userID):
    try:
        # Todos os checkins.checked_out = False de um dado user
        checkins = session.query(Checkin).filter_by(checked_out = False, user_name = userID).all() 

        # Convert Lesson objects to dictionaries
        checkins_list = []
        for checkin in checkins:
            checkins_dict = {
                'id': checkin.id,
                'user_name': checkin.user_name,
                'location': checkin.location,
                'checkin_time': checkin.checkin_time,
                'checkout_time': checkin.checkout_time,
                'checked_out': checkin.checked_out 
            }
            checkins_list.append(checkins_dict)

        return checkins_list
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

def getCheckins(userID):
    try:
        # Query the lessons associated with the room
        checkins = session.query(Checkin).filter_by(user_name=userID).all() # Todos os checkins de um dado user

        # Convert Lesson objects to dictionaries
        checkins_list = []
        for checkin in checkins:
            checkins_dict = {
                'id': checkin.id,
                'user_name': checkin.user_name,
                'location': checkin.location,   
                'checkin_time': checkin.checkin_time,
                'checkout_time': checkin.checkout_time,
                'checked_out': checkin.checked_out 
            }
            checkins_list.append(checkins_dict)

        return checkins_list    
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []
    
@handler.register    
def getCheckins_byRoom(location_id):
    try:
        # Query the lessons associated with the room
        checkins = session.query(Checkin).filter_by(checked_out = False, location=location_id).all() # Todos os checkins de um dado user

        # Convert Lesson objects to dictionaries
        checkins_list = []
        for checkin in checkins:
            checkins_dict = {
                'id': checkin.id,
                'user_name': checkin.user_name,
                'location': checkin.location,   
                'checkin_time': checkin.checkin_time,
                'checkout_time': checkin.checkout_time,
                'checked_out': checkin.checked_out 
            }
            checkins_list.append(checkins_dict)

        return checkins_list    
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

@handler.register
def getLastCheckIn(userID):
    try:
        #Query the lessons associated with the room 
        lastCheckin = session.query(Checkin).filter_by(checked_out = False, user_name = userID).one()
        # Se forem vários temos de .all() e depois sacar o mais recente !!

        # Convert Lesson objects to dict
        lastCheckin_dict = {
            'id': lastCheckin.id,
            'user_name': lastCheckin.location,
            'checkin_time': lastCheckin.checkin_time,
            'checkout_time': lastCheckin.checked_out,
            'checked_out' : lastCheckin_dict
        }
        return lastCheckin_dict
    except Exception as e:
        print(f"Error: {e}")
        return []

@handler.register
def perform_checkinQR(user_name, location, checkin_time_str):
    
    # Convert the datetime string to a Python datetime object
    checkin_time = datetime.strptime(checkin_time_str, '%Y-%m-%dT%H:%M')

    # Create a new Checkin record in the database
    checkin = Checkin(user_name=user_name, location=location, checkin_time=checkin_time, checkout_time=checkin_time, checked_out = False) #location_type=location_type
    session.add(checkin)
    session.commit()

    return "SUCESSO!"

@handler.register
def perform_checkoutQR(user_name, location):
    checkinList = getFalseChecked(user_name) #username or ID

    for falseChecked in checkinList:
        if falseChecked['location'] == location:
            checkin = session.query(Checkin).filter_by(id = falseChecked['id']).one()
            checkin.checked_out = True
            checkin.checkout_time = datetime.now()
            session.commit()

    return "Checked OUT!"


########################


@app.route('/')
def home():
    return render_template("index.html", message="Check-In App!!!!")

@app.route('/checkin', methods=['GET'])
def checkin():
    return render_template('checkin.html')


@app.route('/perform_checkin', methods=['POST'])
def perform_checkin():
    user_name = request.form.get('user_name')
    location = request.form.get('location')
    checkin_time_str = request.form.get('checkin_time')  # Get the datetime string from the form
    #location_type = request.form.get('location_type')

    # Convert the datetime string to a Python datetime object
    checkin_time = datetime.strptime(checkin_time_str, '%Y-%m-%dT%H:%M')

    # Create a new Checkin record in the database
    checkin = Checkin(user_name=user_name, location=location, checkin_time=checkin_time, checkout_time=checkin_time, checked_out = False) #location_type=location_type
    session.add(checkin)
    session.commit()

    return render_template("index.html", message="You just Checked-In!!!!")
    #return redirect(url_for('checkin'))


@app.route('/checkoutPRE', methods=['GET'])
def checkoutPRE():
    return render_template('checkoutPRE.html')

@app.route('/checkout', methods=['POST'])
def checkout():
    userID = request.form.get('user_id')
    checkinList = getFalseChecked(userID) #username or ID

    if not checkinList:
        # No check-ins are found with checked_out=True, display a message
        return render_template('checkout.html',user_id=userID, checkins= checkinList,  message="No Check-ins found")
    
    return render_template('checkout.html', user_id=userID, checkins= checkinList)

@app.route('/checkouts/<int:checkin_id>', methods=['GET']) 
def Chekiout(checkin_id):
    # For example, if you have a database model named Checkin, you can mark the check-in as checked out like this:
    #checkin = Checkin.query.get(checkin_id)
    checkin = session.query(Checkin).filter_by(id =checkin_id).one()
    if checkin:
        checkin.checked_out = True
        checkin.checkout_time = datetime.now()
        #checkout_time = datetime.strptime(checkin_time_str, '%Y-%m-%dT%H:%M')
        #checkout_time_str = checkout_time.strftime('%Y-%m-%dT%H:%M')
        session.commit()

    return render_template("index.html", message="Check-Out Realizado!!!!")

@app.route('/checkListPRE', methods=['GET'])
def checkListPRE():
    return render_template('checkListPRE.html')

@app.route('/checkList', methods=['POST'])
def checkList():
    userID = request.form.get('user_id')
    # Fetch a list of check-ins and check-outs for the specified user
    checkins_and_checkouts = getCheckins(userID)
    return render_template('checkList.html', user_id=userID, checkins_and_checkouts=checkins_and_checkouts)
# ...

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8007, debug=True)
