from flask import Flask, render_template, request, send_from_directory, redirect, jsonify
import os
import qrcode 
app = Flask(__name__)
     
@app.route("/")
def index():
    return render_template("index.html", message="Dynamic content!")   

@app.route("/newQR", methods=['GET','POST'])
def QRCode():
    if request.method == 'GET':
        return render_template("newQR.html")
    elif request.method == 'POST':
        QRtext = request.form["QRName"] 
        QRname = QRtext #+ ".jpeg"
        QRimg = qrcode.make(QRtext)
        directory = "/home/mint/Desktop/ADINT/Projeto/QRCodeGenerator/files/"
        QRpath = directory + QRname
        QRimg.save(os.path.join(directory, QRname), "JPEG", quality=95)
        
        # file verification
        if not os.path.exists(QRpath):
            return redirect('/failure'), QRname
    
        # send file
        return send_from_directory(directory, QRname, as_attachment=True)



if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8001, debug=True)