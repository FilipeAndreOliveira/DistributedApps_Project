from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String

import datetime
from sqlalchemy.orm import sessionmaker
from os import path

from flask import Flask, render_template, request
from flask_xmlrpcre.xmlrpcre import *

app = Flask(__name__)

handler = XMLRPCHandler('api')
handler.connect(app, '/api')

#SQL access layer initialization
DATABASE_FILE = "database.sqlite"
db_exists = False
if path.exists(DATABASE_FILE):
    db_exists = True
    print("\t database already exists")

engine = create_engine('sqlite:///%s'%(DATABASE_FILE), echo=False)

Base = declarative_base()

#Data structures
class Message(Base):
    __tablename__ = 'messages'
    id = Column(Integer, primary_key=True)
    sender = Column(String(20))
    receiver = Column(String(20))
    text = Column(String(100))

#Create tables for the data models
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

def getMessageList_byUser(name): # name sera o ID?
    try:
        messages = session.query(Message).filter((Message.sender == name) | (Message.receiver == name)).all()
        #messages = session.query(Message).filter(or_(Message.name == name, Message.reciver == name)).all()

        # Convert Lesson objects to dictionaries
        messages_list = []
        for message in messages:
            messages_dict = {
                'id': message.id,
                'sender': message.sender,
                'receiver': message.receiver,
                'text': message.text 
            }
            messages_list.append(messages_dict)

        return messages_list
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

def getAllMessagesList():
    try:
        # Query the lessons associated with the room
        messages = session.query(Message).all() # Todos os checkins de um dado user

        # Convert Lesson objects to dictionaries
        messages_list = []
        for message in messages:
            messages_dict = {
                'sender': message.sender,
                'receiver': message.receiver,
                'text': message.text  
            }
            messages_list.append(messages_dict)

        return messages_list
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

#Site stuff
@app.route('/')
def chat():
    return render_template("index.html", message="Welcome to Message App!")

@app.route('/sendMessage', methods=["GET", "POST"])
def sendMessageAdmin():
    if request.method == "GET":
        return render_template("sendMessage.html")
    
    elif request.method == "POST":
        sender = request.form['sender']
        receiver = request.form['receiver']
        text = request.form['message-text']

        new_message = Message(
            sender = sender,
            receiver = receiver,
            text = text
        )
        session.add(new_message)
        session.commit()

    return render_template("index.html", message="Your Message was sent!!")

@app.route('/searchMessageUserPRE', methods=['GET'])
def searchMessageUserAdminPRE():
    return render_template('searchMessageUserPRE.html')

@app.route('/searchMessageUser', methods=["POST"])
def searchMessagesAdmin():

    name = request.form['name']
    messageList = getMessageList_byUser(name) #username or ID
    if not messageList:
        return render_template('searchMessageUser.html', messages=messageList, name=name, message="No Messages found")

    return render_template('searchMessageUser.html', messages=messageList, name=name)

@app.route('/searchMessageGroupPRE', methods=['GET'])
def searchMessageGroupAdminPRE():
    return render_template('searchMessageGroupPRE.html')

@app.route('/searchMessageGroup', methods=['POST'])
def searchMessageUsersAdmin():
    # Get the input usernames as a comma-separated string from the form data
    input_usernames = request.form.get('names')

    # Split the input string into individual usernames
    usernames = [username.strip() for username in input_usernames.split(',')]
    print(usernames)

    groupMessages = []
    for username in usernames:
        userList = getMessageList_byUser(username)
        for userMessage in userList:
            if not any(message['id'] == userMessage['id'] for message in groupMessages): # Toda a messangem tem um id unico
                groupMessages.append(userMessage)
            """isNewmessage = True
            for message in groupMessages:
                if(userMessage['id'] == message['id']):
                    isNewmessage = False
                    break
            if (isNewmessage):
                groupMessages.append(userMessage) """

    # Fetch messages sent by the specified usernames from your database
    # Example: messages = Message.query.filter(Message.sender.in_(usernames)).all()
    return render_template('searchMessageGroup.html', usernames=usernames, messages=groupMessages, message='No messages Here!')

@handler.register
def sendMessage(sender, receiver, text):

    new_message = Message(
        sender = sender,
        receiver = receiver,
        text = text
    )
    session.add(new_message)
    session.commit()

    return 1

@handler.register
def searchMessages(name):
    try:
        messages = session.query(Message).filter((Message.sender == name) | (Message.receiver == name)).all()

        # Convert Lesson objects to dictionaries
        messages_list = []
        for message in messages:
            messages_dict = {
                'id': message.id,
                'sender': message.sender,
                'receiver': message.receiver,
                'text': message.text 
            }
            messages_list.append(messages_dict)
            
        messages_list.reverse()  

        return messages_list
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8009, debug=True)