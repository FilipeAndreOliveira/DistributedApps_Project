from xmlrpc import client

from flask import Flask, render_template, request

app = Flask(__name__)

proxy = client.ServerProxy("http://localhost:8008/api")
 
@app.route("/")
def index():
    return render_template("index.html", message="Welcome Food Admin!!!")   

@app.route("/listRestaurants")
def listRestaurants():
    try:
        #proxy.newRestaurant('Picanha na Brasa')
        #proxy.newRestaurant('Tasca do Zé')

        # Query the restaurants from the database
        lista1 = proxy.listRestaurants() 
        for restaurant in lista1:
            print(f"Restaurant ID: {restaurant['id']}, Name: {restaurant['name']}")

        # Pass the list of restaurants to the HTML template
        return render_template("listRestaurants.html", restaurants=lista1)
    except Exception as e:
        # Handle any exceptions that may occur
        return str(e)
    
@app.route("/showEvaluations", methods=['GET','POST'])
def listEvaluations():
    if request.method == 'GET':
        return render_template("listEvaluations.html", evaluations=None)
    elif request.method == 'POST':
        # Call the list_evaluations_by_restaurant function on the server
        restaurantID = request.form.get("restaurantID")
        restaurantName = proxy.nameRestaurants_fromID(restaurantID)
        evaluationList = proxy.list_evaluations_by_restaurant(restaurantID)

        if not evaluationList:
            return render_template("listEvaluations.html", evaluations=None, no_evaluations=True, restaurantName=restaurantName)

        # Pass the list of evaluations to the HTML template
        return render_template("listEvaluations.html", evaluations=evaluationList, restaurantName=restaurantName)


@app.route("/createRestaurant", methods=['GET','POST'])
def createRestaurant():
    if request.method == 'GET':
        return render_template("createRestaurant.html")
    elif request.method == 'POST':
        restaurantName = request.form["restaurantName"] 
        proxy.newRestaurant(restaurantName)
        return render_template("index.html", message="Restaurant Created Successfully!!!")
        #return "Restaurant Created Successfully!"

@app.route("/updateMenu", methods=['GET','POST'])
def updateMenu():
    if request.method == 'GET':
        return render_template("updateMenu.html")
    elif request.method == 'POST':
        menuName = request.form["menuName"]
        menuFkrestaurant = request.form["menuFkrestaurant"] #restaurant ID, that has that menu
        menuID = request.form["menuID"] # meal ID
        menuPrice = request.form["menuPrice"] 
        
        proxy.update_menu(menuFkrestaurant, menuID, menuName, menuPrice)
        return render_template("index.html", message="Menu Updated Successfully!!!") 

@app.route('/listRestaurants/<int:restaurant_id>', methods=['GET','POST'])
def showMenu(restaurant_id):
    menu = proxy.list_meals_by_restaurant(restaurant_id)
    restaurantName = proxy.nameRestaurants_fromID(restaurant_id)
    return render_template("listMenu.html", restaurantName=restaurantName, restaurantID = restaurant_id, menu=menu)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=True)

