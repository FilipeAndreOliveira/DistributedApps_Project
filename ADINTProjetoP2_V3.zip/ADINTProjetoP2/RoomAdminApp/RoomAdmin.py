from xmlrpc import client

from flask import Flask, render_template, request, redirect

import requests

app = Flask(__name__)

proxy = client.ServerProxy("http://localhost:8004/api")

# Site Stuff

@app.route('/')
def home():
    return render_template("admin.html", message="Room Administrator!")

@app.route('/createFenixRoom')
def getSpaces():
    url = "https://fenix.tecnico.ulisboa.pt/api/fenix/v1/spaces"
    response = requests.get(url)
    spaces_info = response.json()
    print (spaces_info)
    return render_template('createFenixRoom.html', rooms=spaces_info)

@app.route('/createFenixRoom/<int:room_id>', methods=['GET'])
def getSpacesInfo(room_id):
    url = "https://fenix.tecnico.ulisboa.pt/api/fenix/v1/spaces/" + str(room_id)
    response = requests.get(url)
    room_info = response.json()
    #print (room_info)
    return render_template('createFenixRoomInfo.html', roomInfo=room_info)

@app.route('/populateFenixRoom/<int:room_id>', methods=['GET'])
def createSpace(room_id):
    url = "https://fenix.tecnico.ulisboa.pt/api/fenix/v1/spaces/" + str(room_id)
    response = requests.get(url)
    room_info = response.json()

    room_idStr = room_info['id']
    #room_id = int(room_idStr)

    room_type = room_info['type']
    room_name = room_info['name']

    room_description = room_info['description']

    capacity_normal = room_info['capacity']['normal']
    capacity_exam = room_info['capacity']['exam']

    top_level_space_id = room_info['topLevelSpace']['id']
    parent_space_id = room_info['parentSpace']['id']

    #lesson_idStr =  room_info['lesson-id'] NA SALA HA EVENTOS DO TYPE LESSON
    #lesson_id = 123

    proxy.createRoom_from_data(room_idStr, room_type, room_name, room_description, capacity_normal, capacity_exam, top_level_space_id, parent_space_id)

    for evento in room_info['events']:
        if evento['type'] == 'LESSON':
            
            #lesson_id_str = request.form.get('lesson_id')
            #lesson_id = int(lesson_id_str)

            lesson_type = evento['type']
            start_time = evento['start']
            end_time = evento['end']

            period_start = evento['period']['start']
            #period_start = datetime.strptime(period_startStr, "%Y-%m-%d")
            period_end= evento['period']['end']
            #period_end = datetime.strptime(period_endStr, "%Y-%m-%d")

            weekday = evento['weekday']
            day = evento['day']
            info = evento['info']

    
            course_id = evento['course']['id']
            #course_name = evento['course']['name']
            #course_acronym = evento['course']['acronym']
            #course_url = evento['course']['url']

            proxy.createLesson(room_idStr, lesson_type, start_time, end_time, weekday, day, info, period_start, period_end, course_id)

    #print (room_info)

    return render_template("admin.html", message="SALA CRIADA COM SUCESSO!")




@app.route('/createRoom', methods=["GET", "POST"])
def create_room():
    if request.method == "GET":
        return render_template("createRoom.html")
    elif request.method == "POST":

        room_idStr = request.form.get('id')
        room_id = int(room_idStr)
        room_type = request.form.get('type')
        room_name = request.form.get('name')
        room_description = request.form.get('description')
        capacity_normalStr = request.form['capacity-normal']
        capacity_normal = int(capacity_normalStr)
        capacity_examStr = request.form['capacity-exam']
        capacity_exam = int(capacity_examStr)

        top_level_space_idStr = request.form['top-level-space-id']
        top_level_space_id = int(top_level_space_idStr)
        parent_space_idStr = request.form['parent-space-id']
        parent_space_id = int(parent_space_idStr)
        lesson_idStr =  request.form['lesson-id']
        lesson_id = int(lesson_idStr)

        proxy.createRoom_from_data(room_id, room_type, room_name, room_description, capacity_normal, capacity_exam, top_level_space_id, parent_space_id, lesson_id)

        return render_template("createRoom.html")

@app.route('/listRooms')
def show_list():   
    try:
        # Call the get_rooms function to retrieve the list of rooms
        rooms = proxy.roomList()

        if not rooms:
            return render_template('empty.html', message="No rooms yet!")
        else:
            return render_template('rooms.html', rooms=rooms)

    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return render_template('error.html', message = f"Error: {e}")

@app.route('/updateSchedule', methods=["GET"])
def update_schedule():
    return render_template('updateSchedule.html')

@app.route('/addLesson', methods=["POST"])
def createSchedule():
    room_id_str = request.form.get('room_id')
    room_id = int(room_id_str)

    #lesson_id_str = request.form.get('lesson_id')
    #lesson_id = int(lesson_id_str)

    lesson_type = request.form['lesson_type']
    start_time =request.form['start']
    end_time = request.form['end']

    period_start = request.form['period_start']
    #period_start = datetime.strptime(period_startStr, "%Y-%m-%d")
    period_end = request.form['period_end']
    #period_end = datetime.strptime(period_endStr, "%Y-%m-%d")

    weekday = request.form['weekday']
    day = request.form['day']
    info = request.form['info']

    course = request.form.get('course')
    course_id = int(course)

    proxy.createLesson(room_id, lesson_type, start_time, end_time, weekday, day, info, period_start, period_end, course_id)

    redirect_url = f"/roomSchedule/{room_id}"
    return redirect(redirect_url) 

@app.route('/roomSchedule/<int:room_id>', methods=['GET']) 
def roomSchedule(room_id):
    # Fetch the lessons for the specified room
    room_idStr = str(room_id)
    schedule = proxy.getLessons_byRoomSchedule(room_idStr)
    return render_template('room_schedule.html', room_id=room_idStr, schedule=schedule)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8002, debug=True)
