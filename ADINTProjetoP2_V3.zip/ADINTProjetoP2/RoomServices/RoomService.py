from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey


from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.exc import NoResultFound

from os import path

from flask import Flask, render_template
from flask_xmlrpcre.xmlrpcre import *

app = Flask(__name__)

handler = XMLRPCHandler('api')
handler.connect(app, '/api')

#SQL access layer initialization
DATABASE_FILE = "database.sqlite"
db_exists = False
if path.exists(DATABASE_FILE):
    db_exists = True
    print("\t database already exists")

engine = create_engine('sqlite:///%s'%(DATABASE_FILE), echo=False)

Base = declarative_base()

#Data structures
class Room(Base):
    __tablename__ = 'rooms'

    id = Column(Integer, primary_key=True)
    room_type = Column(String)
    name = Column(String)
    description = Column(String)

    # Relationship to TopLevelSpace
    top_level_space_id = Column(Integer, ForeignKey('top_level_spaces.id')) # multiple rooms share the same Top Level
    top_level_space = relationship('TopLevelSpace')

    # Relationship to ParentSpace
    parent_space_id = Column(Integer, ForeignKey('parent_spaces.id')) # multiple rooms share the same parent
    parent_space = relationship('ParentSpace')

    # Capacity as JSONB
    capacity_normal = Column(Integer)
    capacity_exam = Column(Integer)

    # Schedule
    #lesson_id = Column(Integer, ForeignKey('lessons.id')) #multiple rooms share the same lesson
    #lesson = relationship('Lesson') #secondary='room_schedule', back_populates='rooms'
    # Schedule
    lesson_schedule = relationship("RoomSchedule", back_populates="room") 
    #lesson_schedule = relationship("Lesson", secondary="room_schedule", back_populates="room")
    #lessons = relationship("Lesson", secondary="room_schedule", back_populates="rooms")

class TopLevelSpace(Base):
    __tablename__ = 'top_level_spaces'

    id = Column(Integer, primary_key=True)
    space_type = Column(String)
    name = Column(String)

    # Relationship to Room
    rooms = relationship('Room', back_populates='top_level_space')

class ParentSpace(Base):
    __tablename__ = 'parent_spaces'

    id = Column(Integer, primary_key=True)
    space_type = Column(String)
    name = Column(String)

    # Relationship to Room
    rooms = relationship('Room', back_populates='parent_space')

class Lesson(Base):
    __tablename__ = 'lessons'

    id = Column(Integer, primary_key=True) # Integer
    lesson_type = Column(String)
    start = Column(String)
    end = Column(String)
    weekday = Column(String)
    day = Column(String)
    info = Column(String)

    # Define period_start and period_end as computed columns
    period_start = Column(String)
    period_end = Column(String)

    # Relationship to the Course
    course_id = Column(String, ForeignKey('courses.id')) #Integer
    course = relationship('Course')

    #room = relationship("Room", back_populates="lesson") #secondary='room_schedule'
    room_schedule = relationship("RoomSchedule", back_populates="lesson")
    #room_schedule = relationship("Room", secondary="room_schedule", back_populates="lesson")
    #rooms = relationship("Room", secondary="room_schedule", back_populates="lessons")

class Course(Base):
    __tablename__ = 'courses'

    id = Column(Integer, primary_key=True)
    acronym = Column(String)
    name = Column(String)
    academic_term = Column(String)
    url = Column(String)

    # Relationship to the Lesson
    lessons = relationship('Lesson', back_populates='course')

"""class RoomSchedule(Base):
    __tablename__ = 'room_schedule'

    id = Column(Integer, primary_key=True)
    room_id = Column(Integer, ForeignKey('rooms.id'))
    lesson_id = Column(Integer, ForeignKey('lessons.id')) """

class RoomSchedule(Base):
    __tablename__ = 'room_schedule'

    id = Column(Integer, primary_key=True)
    room_id = Column(Integer, ForeignKey('rooms.id'))
    lesson_id = Column(Integer, ForeignKey('lessons.id'))

    room = relationship("Room", back_populates="lesson_schedule")
    lesson = relationship("Lesson", back_populates="room_schedule")



#Create tables for the data models
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()


@handler.register
def roomList():
    try:
        # Query the Room objects
        rooms = session.query(Room).all()

        # Convert Room objects to dictionaries to make a list of dictionaries
        room_list = []
        for room in rooms:
            room_dict = {
                'id': str(room.id),
                'room_type': room.room_type,
                'name': room.name,
                'description': room.description,
                'capacity_normal': room.capacity_normal,
                'capacity_exam': room.capacity_exam,
                'top_level_space_id': str(room.top_level_space_id), #ForeignKey
                'parent_space_id': str(room.parent_space_id), #ForeignKey
                'lessons': getLessons_byRoomSchedule(room.id)
            }
            room_list.append(room_dict)
        return room_list
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

@handler.register
def createParentSpace(parent_id, parent_space_type, parentName):

    #Verificar se já existe um Parent Space com o parent_id que queremos criar
    parent_space = session.query(ParentSpace).filter_by(id=parent_id).first()

    #Não Havia nenhum, cria-se um.   
    if not parent_space:
        parent_space = ParentSpace(id= parent_id, space_type=parent_space_type, name = parentName) # Meter id?
        session.add(parent_space)
        session.commit()
        return True

    #Havia já um Altera-se o tipo e nome
    else:
        parent_space.space_type = parent_space_type
        parent_space.name = parentName
        session.commit()
        return True

@handler.register
def createTopSpace(top_id, top_space_type, topName):

    #Verificar se já existe um TopLevel Space com o top_id que queremos criar
    top_space = session.query(TopLevelSpace).filter_by(id=top_id).first()

    #Não Havia nenhum, cria-se um.   
    if not top_space:
        top_space = TopLevelSpace(id= top_id, space_type=top_space_type, name = topName) # Meter id?
        session.add(top_space)
        session.commit()
        return True

    #Havia já um Altera-se o tipo e nome
    else:
        top_space.space_type = top_space_type
        top_space.name = topName
        session.commit()
        return True

@handler.register    
def getLessons_byRoomSchedule(roomID):
    #roomIDINT = int(roomID)
    try:
        # Query the Room object by room_id
        roomSchedules = session.query(RoomSchedule).filter_by(room_id=roomID).all()

        lessonList = []
        for roomSchedule in roomSchedules:
            scheduleLesson = session.query(Lesson).filter_by(id = roomSchedule.lesson_id).one()
            lessonList.append(scheduleLesson)


        if roomSchedules: 
            schedule_list = [
                {
                    'id': lesson.id,
                    'lesson_type': lesson.lesson_type,
                    'start': lesson.start,
                    'end': lesson.end,
                    'weekday': lesson.weekday,
                    'day': lesson.day,
                    'info': lesson.info,
                    'course_id': lesson.course_id,
                    'period_start': lesson.period_start,
                    'period_end': lesson.period_end,
                }
                for lesson in lessonList
            ]
            return schedule_list
        else:
            return []  # Return an empty list if the room doesn't exist
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return []

@handler.register
def createLesson(room_id, lesson_type, start_time, end_time, weekday, day, info, period_start, period_end, course_id):
    try:    
        lesson = Lesson(
            #id = lesson_id,
            lesson_type = lesson_type,
            start = start_time,
            end = end_time,
            weekday = weekday,
            day = day,
            info = info,
            period_start =  period_start,
            period_end = period_end,
            course_id = course_id) 
        
        session.add(lesson)
        session.commit()

        room_idINT = int(room_id) 
        # Query the room by room_id
        print(f"room id: {room_id}")
        room = session.query(Room).filter_by(id=room_idINT).first()
        if room:
            # Add the lesson to the room's lessons relationship
            #print("EX-KABUM")
            #room.lesson_schedule.append(lesson)

            #New GPT tips
            print("NO GPT KABUM")
            lesson_schedule = RoomSchedule(room_id=room.id, lesson_id=lesson.id)
            session.add(lesson_schedule)
            print("KABUM")

            # Commit the changes
            session.commit()
            print("Lesson created and associated with the room successfully")
            return True
        else:
            print(f"Room with ID {room_id} not found")
            return False

    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error creating lesson: {e}")
        return False
    
@handler.register
def createRoom_from_data(room_id, room_type, room_name, room_description, capacity_normal, capacity_exam, top_level_space_id, parent_space_id): #top_level_space_type, topName, parent_space_type, parentName -> VERIFICAR ISTO?!
    try:
        # Create a new Room object and populate it with form data
        room_idINT = int(room_id) 
        top_level_space_idINT = int(top_level_space_id)
        parent_space_idINT = int(parent_space_id)
        existing_room = session.query(Room).filter_by(id=room_idINT).first()
        
        if existing_room:
            #APAGAR AS LESSONS ANTIGAS
            # Query the RoomSchedule objects associated with the room
            roomSchedules = session.query(RoomSchedule).filter_by(room_id=room_idINT).all()

            # Create a list of lesson IDs to be deleted
            lessonIDs = [roomSchedule.lesson_id for roomSchedule in roomSchedules]

            # Delete the associated lessons
            for lesson_id in lessonIDs:
                session.query(Lesson).filter_by(id=lesson_id).delete()

            # Delete the associated RoomSchedule entries
            for roomSchedule in roomSchedules:
                session.delete(roomSchedule)

            # Commit the changes to the database
            session.commit()

            existing_room.room_type=room_type
            existing_room.name=room_name
            existing_room.description=room_description
            existing_room.capacity_normal=capacity_normal
            existing_room.capacity_exam=capacity_exam
            existing_room.top_level_space_id = top_level_space_idINT
            existing_room.parent_space_id = parent_space_idINT
            session.commit()
            return "Room updated successfully."
        else:    
        
            new_room = Room(
                id=room_idINT,
                room_type=room_type,
                name=room_name,
                description=room_description,
                capacity_normal=capacity_normal,
                capacity_exam=capacity_exam,
                top_level_space_id = top_level_space_id,
                parent_space_id = parent_space_id,
                #lesson_id = lesson_id
            )   
            session.add(new_room)
            session.commit()
            return "Room created successfully."
    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return "An error occurred while creating the room."

@handler.register
def updateLesson(lessonID, lessonType, startTime, endTime, weekday, day, info, period_start, period_end, course_id):
    try:
        lesson = session.query(Lesson).filter_by(id=lessonID).one()

        lesson.id =lessonID
        lesson.lesson_type = lessonType
        lesson.start = startTime
        lesson.end = endTime
        lesson.weekday = weekday
        lesson.day = day
        lesson.info = info
        lesson.period_start = period_start
        lesson.period_end = period_end
        lesson.course_id = course_id 

        session.commit()
  
        print(f"Lesson ID: {lesson.id}, Lesson type: {lesson.lesson_type}, Start: {lesson.start}, End: {lesson.end}")
        return True  # Return True to indicate a successful update
    
    except NoResultFound:
        print(f"Lesson ID'{lessonID}' not found.")
        return False  # Return False to indicate an error 

# Cenas da web App
@app.route('/')
def home():
    return render_template('service.html', message="Room Service!") 

@app.route('/listRooms') #mostrar todos os rooms
def listRooms():
    try:
        # Call the get_rooms function to retrieve the list of rooms
        rooms = roomList()

        if not rooms:
            return render_template('empty.html', message="No rooms yet!")
        else:
            return render_template('rooms.html', rooms=rooms)

    except Exception as e:
        # Handle exceptions if necessary
        print(f"Error: {e}")
        return render_template('error.html', message = f"Error: {e}")

@app.route('/listRooms/<int:room_id>') #mostrar o schedule da room selecionada
def viewSchedule(room_id):
    #schedule = getLessons_byRoom(room_id)
    schedule = getLessons_byRoomSchedule(room_id)
    return render_template('room_schedule.html', room_id=room_id, schedule=schedule)

app.run(host='0.0.0.0', port=8004, debug=True)

